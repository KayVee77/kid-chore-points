# Core app tests
